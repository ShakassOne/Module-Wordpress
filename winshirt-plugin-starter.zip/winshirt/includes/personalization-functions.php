<?php
// Fonctions de personnalisation et JSON
